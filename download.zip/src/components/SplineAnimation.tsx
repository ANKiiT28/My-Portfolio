import Spline from '@splinetool/react-spline/next';

export default function SplineAnimation() {
  return (
    <Spline
      scene="https://prod.spline.design/9XWuFNAUxpTto6Lw/scene.splinecode"
    />
  );
}
